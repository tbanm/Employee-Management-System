import { Component, OnInit } from '@angular/core';
import { User } from '../user';
import { RegisterService } from '../register.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register-user',
  templateUrl: './register-user.component.html',
  styleUrl: './register-user.component.css'
})
export class RegisterUserComponent implements OnInit{
user:User = new User();
errorMessage: string;
  constructor(private registerService: RegisterService, public router: Router){}
  ngOnInit(): void {
    
  }
  userRegister(){
    console.log(this.user);
    this.registerService.registerUser(this.user).subscribe(data =>{
      this.router.navigate(['/app-login']);
      alert("Successfully User is register?")
    },error=>alert("Sorry User not register"));

    this.errorMessage = "username already exist";
  }

}
