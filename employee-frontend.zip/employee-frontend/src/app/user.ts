export class User {
    name!:string;
    id!:number;
    email!:string;
    phone!:string;
    password!:string;
    cpassword!:string;
    gender!:string;
}
