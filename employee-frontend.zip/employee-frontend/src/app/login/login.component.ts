import { Component, OnInit } from '@angular/core';
import { RegisterService } from '../register.service';
import { UserserviceService } from '../userservice.service';
import { Router } from '@angular/router';
import { User } from '../user';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent implements OnInit{
  user:User = new User();
  errorMessage:string;

  constructor(private userservice:UserserviceService, private router: Router){}


  ngOnInit(): void {
    
  }

  login(){
    this.userservice.getUserData(this.user)
      .subscribe(data=>{
        this.router.navigate(['/header']);
        },err=>{
        this.errorMessage="error :  Username or password is incorrect";
        }
      )
  }
}

