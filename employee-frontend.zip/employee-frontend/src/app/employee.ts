export class Employee {
    id: number;
    firstName:string;
    lastName:string;
    emailId:string;
    gender:string;
    mobilenumber:string;
    address:string;
    department:string;
    salary:number;
}
